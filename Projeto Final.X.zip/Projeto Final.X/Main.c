#include "config.h" 
#include "lcd.h"
#include "adc.h"
#include "rgb.h"
#include "keypad.h"
#include "bits.h"
#include "pwm.h"
#include "atraso.h"
#include "ds1307.h"
#include "i2c.h"
#include "ssd.h"
#include "io.h"
#include "so.h"
// DVD - PLAYER
void main(void) {
    //declara��o das letras do display de 7-Segmentos
    static const char valor[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
    //declara��o das variaveis
    static char display = 0;
    int player = 0, cont, v, aux;
    //Inicializa��o das bibliotecas
    pinMode(DISP_4_PIN, OUTPUT);
    lcdInit();
    adcInit();
    kpInit();
    ssdInit();
    soInit();
    // looping infinito
    for (;;) {
        kpDebounce();
        v = adcRead(0);
        digitalWrite(DISP_4_PIN, LOW);
        soWrite(0x3F);
        //fun��o para volume no display de 7-segmentos
        switch (display) {
            case 0:
                soWrite(v);
                digitalWrite(DISP_4_PIN, HIGH);
                v++;
                atraso_ms(100);
                display = 0;
                break;
        }
        //adiantar reprodu��o
        if (kpReadKey() == 'A') {
            cont = cont + 1000;
        }
        //voltar reprodu��o
        if (kpReadKey() == 'Y') {
            cont = cont - 1000;
        }
        //Segunda linha do LCD Dura��o
        lcdCommand(0xC0); 
        lcdString("Hora: ");
        lcdChar((((cont / 360000) % 24) / 10) + 48);
        lcdChar((((cont / 360000) % 24) % 10) + 48);
        lcdChar(':');
        lcdChar((cont / 60000) % 6 + 48);
        lcdChar((cont / 6000) % 10 + 48);
        lcdChar(':');
        lcdChar((cont / 1000) % 6 + 48);
        lcdChar((cont / 100) % 10 + 48);
        //Primeira Linha do LCD
        lcdCommand(0x80);
        kpDebounce();
        // Bot�o de Pause
        if (kpReadKey() == 'S') {
            player = 4;
        } else if (kpReadKey() == 's') {
            kpDebounce();
            player = aux;
        }
        //Escolha de faixa de Reprodu��o
        switch (player) {
            case 0:
                kpDebounce();
                lcdString("1- Harry Potter");
                cont++;
                aux = player;
                //pular faixa
                if (kpReadKey() == 'R') {
                    lcdCommand(0x01);
                    player = 1;
                    atraso_ms(1000);
                    cont = 0;
                //Voltar faixa
                } else if (kpReadKey() == 'L') {
                    lcdCommand(0x01);
                    kpDebounce();
                    player = 3;
                    atraso_ms(1000);
                    cont = 0;
                }
                break;
            case 1:
                kpDebounce();
                cont++;
                aux = player;
                lcdString("2- Transformers");
                //pular faixa
                if (kpReadKey() == 'R') {
                    lcdCommand(0x01);
                    player = 2;
                    atraso_ms(1000);
                    cont = 0;
                //Voltar faixa    
                } else if (kpReadKey() == 'L') {
                    lcdCommand(0x01);
                    kpDebounce();
                    player = 0;
                    atraso_ms(1000);
                    cont = 0;
                }
                break;
            case 2:
                kpDebounce();
                cont++;
                aux = player;
                lcdString("3- Karate Kid");
                //pular faixa
                if (kpReadKey() == 'R') {
                    lcdCommand(0x01);
                    player = 3;
                    atraso_ms(1000);
                    cont = 0;
                //Voltar faixa    
                } else if (kpReadKey() == 'L') {
                    lcdCommand(0x01);
                    kpDebounce();
                    player = 1;
                    atraso_ms(1000);
                    cont = 0;
                }
                break;
            case 3:
                kpDebounce();
                cont++;
                aux = player;
                lcdString("4- Barbie");
                //pular faixa
                if (kpReadKey() == 'R') {
                    lcdCommand(0x01);
                    player = 0;
                    atraso_ms(1000);
                    cont = 0;
                //Voltar faixa     
                } else if (kpReadKey() == 'L') {
                    lcdCommand(0x01);
                    kpDebounce();
                    player = 2;
                    atraso_ms(1000);
                    cont = 0;
                }
                break;
            case 4:
                atraso_ms(10);
                break;

            default:
                player = 0;
                break;
        }
    }
}
